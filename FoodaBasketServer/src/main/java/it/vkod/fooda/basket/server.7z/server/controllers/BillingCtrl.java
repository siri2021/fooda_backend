package it.vkod.fooda.basket.server.controllers;

import it.vkod.fooda.basket.server.models.Billing;
import it.vkod.fooda.basket.server.repositories.BillingRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;

@Slf4j
@RestController
@RequestMapping("api/basket")
public class BillingCtrl {

    @Autowired
    private BillingRepository repo;

    @PostMapping("/billing/insert")
    public void apiPostInsertBasketBilling(@NotNull @RequestBody final Billing billing) {
        if (repo.existsByFirstNameAndLastNameAndUserIdAndAddressAndPostcode(billing.getFirstName(), billing.getLastName(),
                billing.getUserId(), billing.getAddress(), billing.getPostcode())) {

            apiPutUpdateBasketBilling(billing);

        } else {
            repo.save(billing);
        }
    }

    @PutMapping("/billing/update")
    public void apiPutUpdateBasketBilling(@NotNull @RequestBody Billing billing) {
        billing = repo.findByFirstNameAndLastNameAndUserIdAndAddressAndPostcode(billing.getFirstName(), billing.getLastName(),
                billing.getUserId(), billing.getAddress(), billing.getPostcode());
        repo.save(billing);
    }

    @DeleteMapping("/billing/delete")
    public void apiDeleteBasketBilling(@NotNull @RequestBody final Billing billing) {
        repo.delete(billing);
    }

    @DeleteMapping("/billing/delete/{user_id}")
    public void apiClearBasketContacts(@PathVariable("user_id") final String userId) {
        final Billing billing = apiGetContacts(userId);
        apiDeleteBasketBilling(billing);
    }

    @GetMapping("/billing/select/{user_id}")
    public Billing apiGetContacts(@PathVariable("user_id") final String userId) {
        return repo.findAllByUserId(userId).toArray(Billing[]::new)[0];
    }
}
